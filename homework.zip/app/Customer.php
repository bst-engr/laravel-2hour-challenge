<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'customers';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['first_name', 'last_name', 'phone_number'];

    public static $rules = array(
                              'first_name'=>'required|alpha', 
                              'last_name'=>'required|alpha', 
                              'phone_number'=>'required|numeric|unique:customers'
                            );
    
}
