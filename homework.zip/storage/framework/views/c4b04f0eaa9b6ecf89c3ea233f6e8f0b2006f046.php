<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Edit Booking <?php echo e($booking->id); ?></h1>

    <?php echo Form::model($booking, [
        'method' => 'PATCH',
        'url' => ['/booking', $booking->id],
        'class' => 'form-horizontal',
        'files' => true
    ]); ?>


                    <div class="form-group <?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
                <?php echo Form::label('date', 'Date', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::date('date', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('customer_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('customer_id', 'Customer Id', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('customer_id', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('customer_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('cleaner_id') ? 'has-error' : ''); ?>">
                <?php echo Form::label('cleaner_id', 'Cleaner Id', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('cleaner_id', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('cleaner_id', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

            </div>
        </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>