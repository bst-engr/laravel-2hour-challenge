<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Cleaner <a href="<?php echo e(url('/cleaner/create')); ?>" class="btn btn-primary btn-xs" title="Add New Cleaner"><span class="glyphicon glyphicon-plus" aria-hidden="true"/></a></h1>
    <div class="table">
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th>S.No</th><th> First Name </th><th> Last Name </th><th> Quality Score </th><th> Email </th><th>City Operates in</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cleaner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->first_name); ?></td><td><?php echo e($item->last_name); ?></td><td><?php echo e($item->quality_score); ?></td><td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->city_list); ?></td>
                    <td>
                        <a href="<?php echo e(url('/cleaner/' . $item->id)); ?>" class="btn btn-success btn-xs" title="View Cleaner"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"/></a>
                        <a href="<?php echo e(url('/cleaner/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs" title="Edit Cleaner"><span class="glyphicon glyphicon-pencil" aria-hidden="true"/></a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['/cleaner', $item->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::button('<span class="glyphicon glyphicon-trash" aria-hidden="true" title="Delete Cleaner" />', array(
                                    'type' => 'submit',
                                    'class' => 'btn btn-danger btn-xs',
                                    'title' => 'Delete Cleaner',
                                    'onclick'=>'return confirm("Confirm delete?")'
                            )); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
        <div class="pagination-wrapper"> <?php echo $cleaner->render(); ?> </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>