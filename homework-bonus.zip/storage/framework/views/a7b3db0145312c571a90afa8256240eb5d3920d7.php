<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>City <?php echo e($city->id); ?>

        <a href="<?php echo e(url('city/' . $city->id . '/edit')); ?>" class="btn btn-primary btn-xs" title="Edit City"><span class="glyphicon glyphicon-pencil" aria-hidden="true"/></a>
        <?php echo Form::open([
            'method'=>'DELETE',
            'url' => ['city', $city->id],
            'style' => 'display:inline'
        ]); ?>

            <?php echo Form::button('<span class="glyphicon glyphicon-trash" aria-hidden="true"/>', array(
                    'type' => 'submit',
                    'class' => 'btn btn-danger btn-xs',
                    'title' => 'Delete city',
                    'onclick'=>'return confirm("Confirm delete?")'
            )); ?>

        <?php echo Form::close(); ?>

    </h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <tbody>
                <tr>
                    <th>ID</th><td><?php echo e($city->id); ?></td>
                </tr>
                <tr><th> City Name </th><td> <?php echo e($city->city_name); ?> </td></tr>
            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>