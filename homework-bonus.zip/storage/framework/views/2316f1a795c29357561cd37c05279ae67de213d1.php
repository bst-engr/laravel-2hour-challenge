<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Schedule Booking</h1>
    <hr/>

    <?php echo Form::open(['url' => '/schedule', 'class' => 'form-horizontal', 'files' => true]); ?>

            <?php if(Session::has('fail_flash_message')): ?>
            <div class="alert alert-danger">
                <?php echo e(Session::get('fail_flash_message')); ?>

            </div>
            <?php endif; ?>
            <?php if(Session::has('success_flash_message')): ?>
            <div class="alert alert-danger">
                <?php echo e(Session::get('success_flash_message')); ?>

            </div>
            <?php endif; ?>
            <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                <?php echo Form::label('first_name', 'First Name', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('first_name', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
                <?php echo Form::label('last_name', 'Last Name', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('last_name', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('phone_number') ? 'has-error' : ''); ?>">
                <?php echo Form::label('phone_number', 'Phone Number', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('phone_number', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('phone_number', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>

            <h3>Booking Time</h3>
            
            <div class="form-group <?php echo e($errors->has('date') ? 'has-error' : ''); ?>">
                <?php echo Form::label('date', 'Date', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::date('date', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('date', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            
             <div class="form-group" >
                <?php echo Form::label('Location / City', 'Location / City', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::select('city_id', $citylist, null, ['class' => 'form-control']); ?>

                </div>
            </div>

        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

            </div>
        </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>